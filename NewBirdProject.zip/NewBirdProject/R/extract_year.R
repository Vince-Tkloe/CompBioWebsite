# extract_year.R
extract_year <- function(file_path) {
  year <- stringr::str_extract(file_path, "\\d{4}")
  return(as.integer(year))
}
