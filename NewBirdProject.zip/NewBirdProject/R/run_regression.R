# run_regression.R
run_regression <- function(summary_df) {
  model <- lm(richness ~ abundance, data = summary_df)
  return(summary(model))
}
