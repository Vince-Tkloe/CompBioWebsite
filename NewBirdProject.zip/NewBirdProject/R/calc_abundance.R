# calc_abundance.R
calc_abundance <- function(df) {
  sum(df$SpeciesTotal)  # Change "SpeciesTotal" if your column has a different name
}
