# calc_richness.R
calc_richness <- function(df) {
  length(unique(df$Species))  # Change "Species" if your species column has a different name
}

