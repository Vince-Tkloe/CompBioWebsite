# make_histograms.R
make_histograms <- function(summary_df, output_dir) {
  library(ggplot2)
  
  # Abundance histogram
  p1 <- ggplot(summary_df, aes(x = abundance)) +
    geom_histogram(binwidth = 10, fill = "skyblue", color = "black") +
    ggtitle("Histogram of Abundance") +
    xlab("Abundance") +
    ylab("Frequency")
  ggsave(filename = file.path(output_dir, "abundance_hist.png"), plot = p1)
  
  # Species richness histogram
  p2 <- ggplot(summary_df, aes(x = richness)) +
    geom_histogram(binwidth = 2, fill = "lightgreen", color = "black") +
    ggtitle("Histogram of Species Richness") +
    xlab("Species Richness") +
    ylab("Frequency")
  ggsave(filename = file.path(output_dir, "richness_hist.png"), plot = p2)
}


