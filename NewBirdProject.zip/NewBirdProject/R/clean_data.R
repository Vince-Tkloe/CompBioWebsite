# clean_data.R
clean_data <- function(df) {
df <- na.omit(df)
return(df)
}

