# Load necessary libraries
library(tidyverse)
library(stringr)
library(broom)

# Source user-defined functions
source("R/clean_data.R")
source("R/extract_year.R")
source("R/calc_abundance.R")
source("R/calc_richness.R")
source("R/run_regression.R")
source("R/make_histograms.R")

# Get list of countdata files
data_files <- list.files("data", recursive = TRUE, full.names = TRUE, pattern = "countdata.*\\.csv$")

# Initialize summary dataframe
summary_stats <- data.frame(
  file = character(),
  year = numeric(),
  abundance = numeric(),
  richness = numeric(),
  stringsAsFactors = FALSE
)

# Loop through each file to calculate metrics
for (file in data_files) {
  df <- read.csv(file)
  df <- clean_data(df)
  year <- extract_year(file)
  abundance <- calc_abundance(df)
  richness <- calc_richness(df)
  
  summary_stats <- rbind(summary_stats, data.frame(
    file = basename(file),
    year = year,
    abundance = abundance,
    richness = richness
  ))
}

# Save summary statistics
write.csv(summary_stats, "output/summaries.csv", row.names = FALSE)

# Run regression and save summary
reg_summary <- run_regression(summary_stats)
write.csv(as.data.frame(reg_summary$coefficients), "output/regression_summary.csv", row.names = TRUE)

# Generate and save histograms
make_histograms(summary_stats, "output/plots")



